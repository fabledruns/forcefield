// Package runtime wires together config, skills, the agent, and a model
// provider to execute a single task. This is the "harness" itself: it
// contains no business logic of its own beyond ordering these steps.
package runtime

import (
	"fmt"

	"forcefield/internal/agent"
	"forcefield/internal/config"
	"forcefield/internal/providers"
	"forcefield/internal/skills"
)

// Run executes one task end-to-end:
//  1. load config
//  2. load skills
//  3. build the agent's system prompt
//  4. call the configured model provider
//  5. return the model's response
//
// It returns the response text, or an error with enough context to know
// which step failed.
func Run(task string) (string, error) {
	cfg, err := config.Load()
	if err != nil {
		return "", fmt.Errorf("load config: %w", err)
	}

	forcefieldHome, err := config.Dir()
	if err != nil {
		return "", fmt.Errorf("resolve forcefield home: %w", err)
	}

	skillsText, err := skills.Load(forcefieldHome)
	if err != nil {
		return "", fmt.Errorf("load skills: %w", err)
	}

	a := agent.New(cfg.Agent.Name, cfg.Agent.SystemPrompt, skillsText)
	systemPrompt := a.BuildSystemPrompt()

	provider, err := newProvider(cfg)
	if err != nil {
		return "", err
	}

	response, err := provider.Chat(systemPrompt, task)
	if err != nil {
		return "", fmt.Errorf("model call failed: %w", err)
	}

	return response, nil
}

// newProvider selects and constructs a ModelProvider based on
// cfg.Model.Provider. Only "ollama" is supported in this prototype;
// anything else fails fast with a clear message.
func newProvider(cfg *config.Config) (providers.ModelProvider, error) {
	switch cfg.Model.Provider {
	case "ollama":
		return providers.NewOllamaProvider(cfg.Model.Endpoint, cfg.Model.Name), nil
	default:
		return nil, fmt.Errorf(
			"unsupported model provider %q (only \"ollama\" is supported in this prototype)",
			cfg.Model.Provider,
		)
	}
}
